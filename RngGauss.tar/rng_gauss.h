
/*******************************************************************************
*
* file rng_gauss.h
*
* Copyright (C) 2016 Sebastian Schmalzbauer
*
* This software is distributed under the terms of the GNU General Public
* License (GPL)
*
*******************************************************************************/

double getOneGaussianRandomNumber(double s);
double getManyGaussianRandomNumbers(double g[], int n, double s);
