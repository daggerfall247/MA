
/*******************************************************************************
*
* File rng_gauss.c
*
* Copyright (C) 2019 Francesca Cuteri
* Copyright (C) 2016 Sebastian Schmalzbauer
*
* This software is distributed under the terms of the GNU General Public
* License (GPL)
*
* Random number generator "rng_gauss"
*
* Use the routines from "ranlxd" of Martin Luescher to init, set the seed, etc.
*
* The externally accessible functions are
*
*   double getOneGaussianRandomNumber(double sigma)
*     Returns a single Gaussian random number with standard deviation sigma
*     However, we always get Gaussian random numbers in pairs and do not want to
*     waste one out of two. Hence we check the value of the 'gaussian_state'
*     global variable to know whether we already have one unused, already drawn,
*     Gaussian random number (that we can retrieve from the globalarray 
*     'gaussian_lookup') or we need to draw two new ones.
*
*   void getManyGaussianRandomNumbers(double g[], int n, double sigma)
*     Fills the first n elements of the array g with Gaussian random numbers
*     with standard deviation sigma
*
*******************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include "ranlxd.h"
#include <math.h>

double uniform_lookup[2];
int gaussian_state = 0;
double gaussian_lookup[2];
double r, phi;

double getOneGaussianRandomNumber(double sigma)
{
   if(gaussian_state == 0)
   {
      ranlxd(uniform_lookup, 2);
      r = sqrt(-2.0*pow(sigma,2)*log(uniform_lookup[0]));
      phi = 2.0*M_PI*uniform_lookup[1];
      gaussian_lookup[0] = r*cos(phi);
      gaussian_lookup[1] = r*sin(phi);
      gaussian_state = 1;
      return gaussian_lookup[0];
   }
   else
   {
      gaussian_state = 0;
      return gaussian_lookup[1];
   }
}


void getManyGaussianRandomNumbers(double g[], int n, double sigma)
{
   int i;   
   for(i = 0; i < n;)
   {
      ranlxd(uniform_lookup, 2);
      r = sqrt(-2.0*pow(sigma,2)*log(uniform_lookup[0]));
      phi = 2.0*M_PI*uniform_lookup[1];
      g[i++] = r*cos(phi);
      if (i < n)
         g[i++] = r*sin(phi);
   }
}

